#define RAW_OUTPUT
#define WRITES_DEPTH

#moj_import <create_assembly_animation:effects.glsl>

uniform float HoloStart;
uniform float BuildStart;
uniform float BuildSpread;
uniform float DismantleStart;
uniform float DismantleSpread;
uniform float Highlight;

const vec3 HOLOGRAM = vec3(0.45, 0.80, 1.00);
const vec3 FICSIT = vec3(1.00, 0.55, 0.16);
const vec3 DISMANTLE = vec3(1.00, 0.22, 0.12);

const float RISE = 0.1;
const float HOLD = 0.35;
const float COOL = 1.3;
const float EDGE_COOL = 1.9;
const float FLARE = 0.15;
const float TAKE = 0.45;

float order(vec3 block) {
    return clamp(length(block + 0.5) / max(Reach, 1.0), 0.0, 1.0) * 0.85 + latticeHash(ivec3(block)) * 0.15;
}

float sinceBuilt(vec3 block) {
    return BuildStart < 0.0 ? -1.0e6 : Time - (BuildStart + order(block) * BuildSpread);
}

float sinceTaken(vec3 block) {
    return DismantleStart < 0.0 ? -1.0e6 : Time - (DismantleStart + (1.0 - order(block)) * DismantleSpread);
}

float buildHeat(float since, float cool) {
    return since < 0.0 ? 0.0 : smoothstep(0.0, RISE, since) * (1.0 - smoothstep(RISE + HOLD, RISE + HOLD + cool, since));
}

float takeHeat(float taken) {
    return taken < 0.0 ? 0.0 : smoothstep(0.0, FLARE, taken) * (1.0 - smoothstep(FLARE, FLARE + TAKE, taken));
}

vec3 hot(float h) {
    vec3 color = mix(vec3(0.55, 0.10, 0.02), vec3(1.00, 0.42, 0.08), smoothstep(0.0, 0.35, h));
    color = mix(color, vec3(1.00, 0.72, 0.30), smoothstep(0.3, 0.65, h));
    return mix(color, vec3(1.00, 0.95, 0.84), smoothstep(0.6, 1.0, h));
}

vec3 heated(Pixel pixel, float heat, float edgeHeat) {
    float flicker = 0.86 + 0.28 * valueNoise(pixel.pos * 3.0 + vec3(0.0, Time * 4.0, Time * 1.3));
    vec3 glow = hot(heat) * flicker;
    float body = smoothstep(0.35, 0.85, heat);
    vec3 color = mix(pixel.color + glow * heat * 0.6, glow * 1.3, body);
    float edge = 1.0 - smoothstep(0.0, 0.07, faceEdge(pixel.inBlock));
    color += FICSIT * edge * edgeHeat * 1.6;
    return pixel.color + (color - pixel.color) * Brightness;
}

vec3 hologram(Pixel pixel, vec3 back) {
    float edge = 1.0 - smoothstep(0.0, 0.05, faceEdge(pixel.inBlock));
    float lines = smoothstep(0.8, 1.0, fract(pixel.pos.y * 5.0 - Time * 1.2));
    float flicker = 0.93 + 0.07 * sin(Time * 37.0 + pixel.pos.y * 3.0);
    vec3 body = HOLOGRAM * (0.30 + 0.60 * luminance(pixel.color));
    vec3 color = mix(back, body, 0.45) * flicker;
    return color + HOLOGRAM * (edge * 0.85 + lines * 0.14) * Brightness;
}

vec4 halo(Pixel pixel) {
    float sum = 0.0;
    float total = 0.0;
    for (int ring = 0; ring < 2; ring++) {
        float radius = ring == 0 ? 12.0 : 28.0;
        float weight = ring == 0 ? 1.0 : 0.6;
        for (int i = 0; i < 10; i++) {
            float angle = (float(i) + 0.5 * float(ring)) * 0.62831853;
            vec2 at = pixel.screen + vec2(cos(angle), sin(angle)) * radius / ScreenSize;
            total += weight;
            if (!buildAt(at))
                continue;
            vec3 block = floor(blockSpaceAt(at));
            float heat = max(buildHeat(sinceBuilt(block), COOL), takeHeat(sinceTaken(block)));
            sum += heat * weight;
        }
    }
    float glow = sum / total;
    if (glow <= 0.002)
        return vec4(0.0);
    return vec4(hot(0.55 + 0.45 * glow) * 1.2, clamp(glow * 1.5, 0.0, 1.0) * 0.8 * min(Brightness, 1.0));
}

vec4 animate(Pixel pixel) {
    if (pixel.inside < 0.5)
        return halo(pixel);

    float holo = HoloStart >= 0.0 ? clamp((Time - HoloStart) / 0.3, 0.0, 1.0) : 0.0;
    float built = sinceBuilt(pixel.block);
    float taken = sinceTaken(pixel.block);

    if (built >= 0.0 && (built >= RISE || pixel.inBlock.y <= built / RISE)) {
        float heat = buildHeat(built, COOL);
        float edgeHeat = buildHeat(built, EDGE_COOL);
        if (edgeHeat <= 0.001)
            return vec4(pixel.color, 0.0);
        return vec4(heated(pixel, heat, edgeHeat), 1.0);
    }

    if (taken >= FLARE + TAKE) {
        vanished = 1.0;
        vec3 back = behind(pixel.screen);
        return vec4(holo > 0.0 ? mix(back, hologram(pixel, back), holo) : back, 1.0);
    }

    if (taken >= 0.0) {
        float heat = taken < FLARE ? smoothstep(0.0, FLARE, taken) : 1.0;
        float burn = smoothstep(FLARE, FLARE + TAKE, taken + valueNoise(pixel.pos * 6.0) * 0.12);
        vec3 color = heated(pixel, heat * (1.0 - burn * 0.5), heat);
        return vec4(mix(color, behind(pixel.screen), burn), 1.0);
    }

    if (Highlight > 0.001) {
        float edge = 1.0 - smoothstep(0.0, 0.06, faceEdge(pixel.inBlock));
        vec3 tint = mix(pixel.color, DISMANTLE * (0.35 + 0.65 * luminance(pixel.color)), 0.4 * Highlight);
        return vec4(tint + DISMANTLE * edge * Highlight * 0.9 * Brightness, 1.0);
    }

    if (holo > 0.0)
        return vec4(mix(pixel.color, hologram(pixel, behind(pixel.screen)), holo), 1.0);
    return vec4(pixel.color, 0.0);
}
