#define RAW_OUTPUT
#define WRITES_DEPTH

#moj_import <create_assembly_animation:effects.glsl>

const float FLASH_RISE = 6.0;
const float FLASH_FALL = 18.0;
const float GATHER = 18.0;
const float REFORM = 60.0;
const float GLINT = 16.0;
const float REFORM_START = FLASH_RISE + GATHER;
const float REFORM_END = REFORM_START + REFORM;
const float REFORM_TO = 1.14;

const vec3 GOLD = vec3(1.0, 0.80, 0.42);

vec3 wind() {
    vec3 level = vec3(StartRight.x, 0.0, StartRight.z);
    level = dot(level, level) < 1.0e-4 ? vec3(1.0, 0.0, 0.0) : normalize(level);
    return normalize(level + vec3(0.0, 0.25, 0.0));
}

float downwind(vec3 p, vec3 w) {
    float low = 1.0e9;
    float high = -1.0e9;
    for (int corner = 0; corner < 8; corner++) {
        vec3 at = vec3((corner & 1) == 0 ? BoundsMin.x : BoundsMax.x, (corner & 2) == 0 ? BoundsMin.y : BoundsMax.y,
                (corner & 4) == 0 ? BoundsMin.z : BoundsMax.z);
        low = min(low, dot(at, w));
        high = max(high, dot(at, w));
    }
    return clamp((dot(p, w) - low) / max(high - low, 0.001), 0.0, 1.0);
}

float snapKey(vec3 p, vec3 w) {
    return (1.0 - downwind(p, w)) * 0.72 + fbm(p * 2.5) * 0.28;
}

vec3 ashen(vec3 color, vec3 p) {
    float grain = valueNoise(p * 16.0);
    vec3 grey = desaturate(color, 0.85) * 0.55;
    return mix(grey, vec3(0.20, 0.18, 0.16), 0.45) * (0.72 + 0.56 * grain);
}

vec4 animate(Pixel pixel) {
    if (Stage == ALIGNMENT)
        return vec4(pixel.color, 0.0);

    float t = Time * 20.0;
    float reform = t < REFORM_START ? -1.0 : clamp((t - REFORM_START) / REFORM, 0.0, 1.0) * REFORM_TO;
    bool hidden = t >= FLASH_RISE && t < REFORM_START;
    float flash = t < FLASH_RISE ? smoothstep(0.0, 1.0, t / FLASH_RISE)
            : 1.0 - smoothstep(0.0, 1.0, (t - FLASH_RISE) / FLASH_FALL);
    float glint = t > REFORM_END ? clamp((t - REFORM_END) / GLINT, 0.0, 1.0) : 0.0;

    vec3 w = wind();
    float back = 1.0 - snapKey(pixel.pos, w);
    float present = 1.0;
    float ash = 0.0;
    float rim = 0.0;
    if (hidden) {
        present = 0.0;
    } else if (reform >= 0.0) {
        present = step(back, reform);
        ash = 1.0 - smoothstep(back, back + 0.12, reform);
        rim = 1.0 - smoothstep(0.0, 0.025, reform - back);
    }

    float band = glint > 0.0 && glint < 1.0 ? exp(-pow((downwind(pixel.pos, w) - (glint * 1.4 - 0.2)) * 5.0, 2.0)) : 0.0;
    float light = flash + band * 0.5;

    if (present < 0.5) {
        vanished = 1.0;
        return vec4(behind(pixel.screen) + GOLD * flash * 0.45 * Brightness, 1.0);
    }
    if (ash <= 0.001 && light <= 0.001)
        return vec4(pixel.color, 0.0);

    vec3 color = mix(pixel.color, ashen(pixel.color, pixel.pos), ash) * (1.0 - rim * ash * 0.55);
    color += GOLD * light * 1.3 * Brightness;
    return vec4(color, 1.0);
}
