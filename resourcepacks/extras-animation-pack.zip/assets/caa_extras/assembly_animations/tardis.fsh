#define RAW_OUTPUT

#moj_import <create_assembly_animation:effects.glsl>

const float PULSES = 3.0;
const float PULSE = 24.0;
const float WHEEZE = PULSES * PULSE;
const float GAP = 10.0;
const float LANDING = WHEEZE + GAP;
const float LANDED = LANDING + WHEEZE;
const float TWO_PI = 6.2831855;

float flight(float t) {
    if (t <= 0.0)
        return 1.0;
    if (t < WHEEZE) {
        float u = t / WHEEZE;
        return pow(1.0 - u, 0.9) * (0.68 + 0.32 * cos(TWO_PI * PULSES * u));
    }
    if (t < LANDING)
        return 0.0;
    if (t < LANDED) {
        float v = (t - LANDING) / WHEEZE;
        return pow(v, 0.9) * (0.68 + 0.32 * cos(TWO_PI * PULSES * (1.0 - v)));
    }
    return 1.0;
}

float hovering(float t) {
    return 1.0 - 0.08 * smoothstep(0.0, 1.0, t / 20.0) * (0.5 + 0.5 * sin(t * TWO_PI / 40.0));
}

vec4 animate(Pixel pixel) {
    float t = Time * 20.0;
    float opacity;
    float ghost;
    if (Stage == ALIGNMENT) {
        opacity = hovering(t);
        ghost = 0.25 * smoothstep(0.0, 1.0, t / 20.0);
    } else {
        opacity = flight(t);
        ghost = t > 0.0 && t < LANDED ? 4.0 * opacity * (1.0 - opacity) : 0.0;
    }

    if (opacity >= 0.999 && ghost <= 0.001)
        return vec4(pixel.color, 0.0);

    float wave = sin(pixel.pos.y * 9.0 - Time * 7.0) * 0.6 + sin(pixel.pos.x * 5.0 + pixel.pos.z * 4.0 + Time * 5.0) * 0.4;
    vec2 shifted = pixel.screen + vec2(wave * ghost * 1.8 / ScreenSize.x, 0.0);
    vec3 ship = buildAt(shifted) ? texture(SceneColor, shifted).rgb : pixel.color;

    float edge = 1.0 - smoothstep(0.0, 0.07, faceEdge(pixel.inBlock));
    ship += vec3(0.55, 0.78, 1.0) * ghost * Brightness * (0.14 + 0.32 * edge);

    if (opacity >= 0.999)
        return vec4(ship, 1.0);
    return vec4(mix(behind(pixel.screen), ship, opacity), 1.0);
}
