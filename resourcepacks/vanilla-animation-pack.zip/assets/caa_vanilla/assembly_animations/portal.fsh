uniform sampler2D EndPortal;
uniform sampler2D EndSky;

vec3 theEnd(vec2 uv) {
    vec3 sum = texture(EndSky, uv * 1.4).rgb * 0.30;
    for (int layer = 0; layer < 6; layer++) {
        float depth = float(layer);
        vec2 drift = vec2(Time * (0.013 + depth * 0.011), Time * (0.009 + depth * 0.008));
        vec3 stars = texture(EndPortal, uv * (1.0 + depth * 0.75) + drift).rgb;
        vec3 tint = vec3(0.30 + depth * 0.10, 0.09 + depth * 0.05, 0.55 + depth * 0.07);
        sum += stars * tint * (0.95 - depth * 0.12);
    }
    return sum;
}

vec4 animate(Pixel pixel) {
    bool standby = Stage == ALIGNMENT;
    float t = standby ? 0.0 : Progress;

    float front = t * 1.3 - 0.15;
    float above = pixel.bounds.y + pixel.random * 0.08 + pixel.distance * 0.05 - front;
    float open = standby ? 1.0 : clamp(above * 6.0, 0.0, 1.0);
    float rim = standby ? 0.0 : exp(-abs(above) * 11.0);

    vec2 uv = pixel.screen * vec2(ScreenSize.x / ScreenSize.y, 1.0) * 1.3;
    vec3 colour = theEnd(uv) + vec3(0.72, 0.36, 1.0) * rim * 1.5;
    colour += vec3(0.45, 0.20, 0.85) * open * 0.25;

    float opening = Stage == ASSEMBLY ? clamp(Time / 0.3, 0.0, 1.0) : 1.0;
    return vec4(colour, max(open, rim * 0.95) * opening);
}
