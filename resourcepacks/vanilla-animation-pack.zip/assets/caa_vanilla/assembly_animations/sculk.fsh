#moj_import <create_assembly_animation:effects.glsl>

const vec3 SCULK = vec3(0.02, 0.09, 0.12);
const vec3 SOUL = vec3(0.16, 0.95, 0.92);

vec4 animate(Pixel pixel) {
    vec3 texel = pixel.block + min(floor(pixel.inBlock * 16.0), 15.0) / 16.0;
    float edge = 1.0 - smoothstep(0.0, 0.06, faceEdge(pixel.inBlock));

    if (Stage == ALIGNMENT) {
        float beat = pow(fract(Time * 0.5 - pixel.distance), 6.0);
        return vec4(pixel.color + SOUL * edge * beat, 1.0);
    }

    float reach = length(texel) / Reach;
    float from = Stage == ASSEMBLY ? reach : 1.0 - reach;
    float age = Progress * 1.45 - from * 0.6 - valueNoise(texel * 1.5) * 0.1;
    float cover = smoothstep(0.0, 0.03, age) * (1.0 - smoothstep(0.55, 0.75, age));

    float veins = 1.0 - smoothstep(0.0, 0.04, abs(fbm(texel * 1.2) - 0.5));
    float specks = step(0.94, hash(texel));
    float pulse = 0.4 + 0.6 * pow(0.5 + 0.5 * sin(Time * 7.0 - reach * 18.0), 3.0);
    vec3 sculk = SCULK + pixel.color * 0.1 + SOUL * (edge * 0.3 + veins * 0.9 + specks * 1.2) * pulse;

    float fronts = exp(-abs(age) * 30.0) + exp(-abs(age - 0.65) * 30.0) * 0.5;
    return vec4(mix(pixel.color, sculk, cover) + SOUL * fronts * 0.8, 1.0);
}
