#moj_import <create_assembly_animation:effects.glsl>

uniform sampler2D Copper;
uniform float CopperFrames;
uniform float Wax;

const vec3 STAGES[4] = vec3[4](vec3(0.78, 0.45, 0.33), vec3(0.64, 0.50, 0.40), vec3(0.42, 0.62, 0.47),
        vec3(0.33, 0.66, 0.55));
const vec3 SHINE = vec3(1.0, 0.82, 0.52);

vec2 faceUv(vec3 at, out float shade) {
    vec3 gap = min(at, 1.0 - at);
    if (gap.y <= gap.x && gap.y <= gap.z) {
        shade = at.y > 0.5 ? 1.0 : 0.5;
        return at.xz;
    }
    if (gap.x <= gap.z) {
        shade = 0.6;
        return vec2(at.x > 0.5 ? 1.0 - at.z : at.z, 1.0 - at.y);
    }
    shade = 0.8;
    return vec2(at.z > 0.5 ? at.x : 1.0 - at.x, 1.0 - at.y);
}

vec3 sheen(Pixel pixel) {
    float band = pow(max(sin(dot(pixel.pos, vec3(0.6, 1.0, 0.4)) * 0.9 - Time * 5.0), 0.0), 40.0);
    return SHINE * band * (0.4 + luminance(pixel.color));
}

vec4 animate(Pixel pixel) {
    if (Stage == ALIGNMENT)
        return vec4(pixel.color + sheen(pixel) * Wax * 0.5, 1.0);
    bool back = Stage == DISASSEMBLY;

    float scrape = clamp((Progress - 0.7) / 0.22, 0.0, 1.0);
    float height = mix(BoundsMin.y - 0.3, BoundsMax.y + 0.3, back ? 1.0 - scrape : scrape);
    float passed = back ? pixel.pos.y - height : height - pixel.pos.y;
    float blade = scrape > 0.0 && scrape < 1.0 ? exp(-abs(passed) * 8.0) * 1.6 : 0.0;
    if (passed > 0.0)
        return vec4(pixel.color + SHINE * blade + sheen(pixel) * Wax * exp(-passed * 0.8), 1.0);

    float order = back ? 1.0 - pixel.distance : pixel.distance;
    float since = Progress - (order * 0.2 + pixel.random * 0.03);
    vec3 cube;
    bool whole = onCubeFace(pixel, cube);
    vec3 at = whole ? clamp(pixel.pos - cube, 0.0, 1.0) : pixel.inBlock;
    if (since < 0.0 || at.y > since / 0.03)
        return vec4(pixel.color, 0.0);

    float rust = clamp(since / 0.42, 0.0, 1.0);
    vec3 texel = (whole ? cube : pixel.block) + min(floor(at * 16.0), 15.0) / 16.0;
    float blotch = valueNoise(texel * 1.5) * 0.7 + hash(texel) * 0.3;
    float level = clamp(floor(rust * 4.2 - blotch * 1.2), 0.0, 3.0);

    vec3 color;
    if (whole) {
        float shade;
        vec2 uv = faceUv(at, shade);
        color = frame(Copper, CopperFrames, level, uv).rgb * shade * mix(0.4, 1.0, Daylight);
    } else {
        color = STAGES[int(level)] * (0.3 + 0.9 * luminance(pixel.color));
    }
    color += SHINE * (exp(-since * 50.0) * 1.2 + blade);
    color += sheen(pixel) * (1.0 - rust) * 0.6;
    return vec4(color, 1.0);
}
